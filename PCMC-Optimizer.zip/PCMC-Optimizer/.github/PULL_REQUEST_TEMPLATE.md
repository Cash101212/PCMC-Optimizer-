## What does this change?

## Checklist
- [ ] New tweaks use `Set-Reg` / `Add-Journal` so **Undo** works
- [ ] Tier is honest (1 Safe, 2 Moderate, 3 Advanced); risky steps use `-Ask`
- [ ] Ran `tools/New-ModuleDocs.ps1` and committed `docs/MODULES.md`
- [ ] Files are ASCII-only
- [ ] Tested with `-DryRun` and on a real machine
