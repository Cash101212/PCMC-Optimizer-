---
name: Bug report
about: Something broke or behaved unexpectedly
labels: bug
---

**Action id** (e.g. `Power.Ultimate`):

**What happened:**

**What you expected:**

**Environment**
- Windows version/build:
- PowerShell version (`$PSVersionTable.PSVersion`):
- Minecraft launcher (official / Prism / CurseForge / ...):

**Log file** (from `%USERPROFILE%\PCMC-Optimizer\logs`):
