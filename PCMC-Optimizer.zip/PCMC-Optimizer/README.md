# PCMC Optimizer

A modular, **fully reversible** performance toolkit for **Windows 10/11 and Minecraft** (Java + Bedrock), written in PowerShell.

61 actions across 13 categories, three risk tiers, one-click presets, an undo journal and a before/after report.

> Every tweak is journaled. Menu **U** (or `-Undo`) puts everything back.

## Quick start

1. Download or clone this repo.
2. Double-click **`Run.bat`** (or run `powershell -ExecutionPolicy Bypass -File .\PCMC-Optimizer.ps1`). It asks for admin rights itself.
3. Pick a preset:

| Preset | Runs | Use when |
|--------|------|----------|
| **S** Safe | Tier 1 only | You want zero-risk wins |
| **B** Balanced | Tier 1 + 2 | Recommended for most PCs |
| **X** Extreme | Tier 1 + 2 + 3 | Desktop gaming PC, you read `docs/MODULES.md` |

4. Restart your PC, then open **R** for the before/after report.

## Categories

| Category | What it covers |
|----------|----------------|
| **Power** | Dedicated Ultimate Performance plan, USB suspend, CPU unparking, hibernation |
| **Gaming** | Game Mode, capture overhead, mouse acceleration, exclusive fullscreen, MMCSS, HAGS, scheduler, timer resolution |
| **Visuals** | Transparency, animations, clean taskbar and Explorer, optional dark mode |
| **Network** | DNS flush/provider, TCP defaults, Delivery Optimization, Nagle off |
| **Memory** | Kernel in RAM (16 GB+), SysMain (SSD only) |
| **Storage** | Temp, shader, browser and update caches, Recycle Bin, TRIM, Storage Sense, DISM cleanup |
| **Services** | Telemetry and rarely-used services (Xbox services are never touched) |
| **Startup** | Startup delay, telemetry tasks, startup manager |
| **Privacy** | Ad ID, promotions, web search, telemetry level, activity history |
| **Debloat** | Pick preinstalled apps to remove (protected apps never listed) |
| **Repair** | SFC, DISM RestoreHealth, network reset |
| **Minecraft** | options.txt, JVM flags, GPU/CPU priority, Defender exclusion, cleanup, Bedrock, Modrinth mod installer, world backup, Java info |
| **Diagnostics** | System info, top processes, disk health, latency test, HTML report |

Full list with tiers: [docs/MODULES.md](docs/MODULES.md)

## Command line

```powershell
.\PCMC-Optimizer.ps1                               # interactive menu
.\PCMC-Optimizer.ps1 -List                         # list every action
.\PCMC-Optimizer.ps1 -Preset Balanced -Yes         # unattended preset
.\PCMC-Optimizer.ps1 -Run Minecraft                # all non-manual Minecraft actions
.\PCMC-Optimizer.ps1 -Run Power.Ultimate,Gaming.* -DryRun
.\PCMC-Optimizer.ps1 -Undo                         # revert everything
```

| Switch | Meaning |
|--------|---------|
| `-Preset Safe\|Balanced\|Extreme` | Run a preset |
| `-Run <ids or categories>` | Run specific actions (wildcards allowed) |
| `-List` | Show all actions |
| `-Undo` | Revert all recorded changes |
| `-DryRun` | Preview only |
| `-Yes` | Auto-accept prompts |
| `-NoRestorePoint` | Skip the System Restore point |

## Configuration

Edit [`config/settings.json`](config/settings.json):

```json
{
  "MinecraftDir": null,
  "RamAllocationGB": null,
  "RenderDistance": null,
  "SimulationDistance": null,
  "DnsProvider": "Cloudflare",
  "ExcludeActions": ["Gaming.Hags"],
  "LogRetentionDays": 14
}
```

`ExcludeActions` lets you permanently skip any action id.

## Safety

Restore point, change journal, file backups, risk tiers, dry run. See [docs/SAFETY.md](docs/SAFETY.md). This tool does **not** disable Defender, the firewall or Windows Update, and has no fake "RAM cleaner".

## Minecraft

Supports the official launcher plus Prism, MultiMC, PolyMC, CurseForge, Modrinth App and ATLauncher instances. Details and FPS advice: [docs/MINECRAFT.md](docs/MINECRAFT.md).

## Project layout

```
PCMC-Optimizer.ps1   Run.bat   config/   docs/   tests/   tools/
src/Core/      engine, journal, helpers, menu
src/Modules/   one file per category (auto-discovered)
```

Architecture notes: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Contributing: [CONTRIBUTING.md](CONTRIBUTING.md)

## Requirements

- Windows 10 or 11
- Windows PowerShell 5.1 (built in). PowerShell 7 works for most actions; Debloat prefers 5.1
- Administrator rights (auto-elevates)

## Disclaimer

Provided as-is under the MIT license. System tweaks always carry some risk: review the code, keep the restore point, and use `-DryRun` first.
