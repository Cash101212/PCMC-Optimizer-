@echo off
title PCMC Optimizer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PCMC-Optimizer.ps1" %*
