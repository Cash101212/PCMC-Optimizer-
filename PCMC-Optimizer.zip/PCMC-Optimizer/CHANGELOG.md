# Changelog

## 2.0.0
- Rebuilt as a modular repository: core engine + one module file per category
- Risk tiers (Safe / Moderate / Advanced) and presets (Safe, Balanced, Extreme)
- Unified change journal: registry, files, tasks, DNS and power plans are all undoable
- New categories: Network, Memory, Services, Startup, Privacy, Debloat, Repair, Diagnostics
- Minecraft: multi-launcher support (Official, Prism, MultiMC, CurseForge, Modrinth App), Modrinth mod installer, Bedrock tuning, world backup
- CLI parameters (`-Preset`, `-Run`, `-List`, `-Undo`, `-DryRun`, `-Yes`), `config/settings.json`, before/after HTML report
- CI workflow (PSScriptAnalyzer + Pester)

## 1.0.0
- Initial single-file release
