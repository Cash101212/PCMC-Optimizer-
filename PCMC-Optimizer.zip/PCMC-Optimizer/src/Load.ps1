# Loads the engine (Core) and every module (Modules\*.ps1) into the caller's scope.
# Dot-source this file:  . .\src\Load.ps1
$script:RepoRoot = Split-Path $PSScriptRoot -Parent

foreach ($file in (Get-ChildItem -Path (Join-Path $PSScriptRoot 'Core') -Filter '*.ps1' | Sort-Object Name)) {
    . $file.FullName
}
foreach ($file in (Get-ChildItem -Path (Join-Path $PSScriptRoot 'Modules') -Filter '*.ps1' | Sort-Object Name)) {
    . $file.FullName
}
