# Change journal: every modification is recorded so "Undo all" can reverse it.
# Entry types: Registry, File, Command, Task, Dns, PowerPlan
$script:Pending = New-Object System.Collections.ArrayList

function Add-Journal([hashtable]$Entry) {
    $Entry['Time'] = (Get-Date).ToString('s')
    [void]$script:Pending.Add([pscustomobject]$Entry)
}

function Save-Journal {
    if ($script:Pending.Count -eq 0) { return }
    if ($script:DryRun) { $script:Pending.Clear(); return }
    $all = @()
    if (Test-Path -LiteralPath $script:JournalFile) {
        $all = @(Get-Content -LiteralPath $script:JournalFile -Raw | ConvertFrom-Json)
    }
    $all += $script:Pending.ToArray()
    ConvertTo-Json -InputObject $all -Depth 6 | Set-Content -LiteralPath $script:JournalFile -Encoding UTF8
    $script:Pending.Clear()
}

function Undo-All {
    Head 'Undo all changes'
    if (-not (Test-Path -LiteralPath $script:JournalFile)) { Warn 'Nothing to undo - journal is empty.'; return }
    $all = @(Get-Content -LiteralPath $script:JournalFile -Raw | ConvertFrom-Json)
    [array]::Reverse($all)
    $done = 0; $failed = 0
    foreach ($e in $all) {
        try {
            switch ($e.Type) {
                'Registry' {
                    if ($e.Existed) {
                        $val = $e.Old
                        switch ($e.OldType) {
                            'Binary' { $val = [byte[]]$e.Old }
                            'DWord'  { $val = [int]$e.Old }
                            'QWord'  { $val = [long]$e.Old }
                        }
                        if (-not (Test-Path -LiteralPath $e.Path)) { New-Item -Path $e.Path -Force | Out-Null }
                        Set-ItemProperty -LiteralPath $e.Path -Name $e.Name -Value $val -Type $e.OldType -Force
                    } else {
                        Remove-ItemProperty -LiteralPath $e.Path -Name $e.Name -ErrorAction SilentlyContinue
                    }
                }
                'File' {
                    if (Test-Path -LiteralPath $e.Backup) { Copy-Item -LiteralPath $e.Backup -Destination $e.Original -Force }
                }
                'Command' {
                    $cmdArgs = @($e.ExeArgs)
                    & $e.Exe @cmdArgs 2>$null | Out-Null
                }
                'Task' {
                    Enable-ScheduledTask -TaskPath $e.TaskPath -TaskName $e.TaskName -ErrorAction Stop | Out-Null
                }
                'Dns' {
                    if ($e.OldServers -and @($e.OldServers).Count -gt 0) {
                        Set-DnsClientServerAddress -InterfaceIndex $e.Index -ServerAddresses @($e.OldServers)
                    } else {
                        Set-DnsClientServerAddress -InterfaceIndex $e.Index -ResetServerAddresses
                    }
                }
                'PowerPlan' {
                    if ($e.Original) { & powercfg /setactive $e.Original 2>$null | Out-Null }
                    if ($e.Created)  { & powercfg /delete $e.Created 2>$null | Out-Null }
                }
            }
            $done++
        } catch {
            $failed++
            Bad ("Could not undo {0}: {1}" -f $e.Type, $_.Exception.Message)
        }
    }
    Remove-Item -LiteralPath $script:JournalFile -Force
    Ok "Reverted $done change(s)$(if ($failed) { ", $failed failed" })."
    Info 'Restart your PC to fully apply the restored settings.'
}
