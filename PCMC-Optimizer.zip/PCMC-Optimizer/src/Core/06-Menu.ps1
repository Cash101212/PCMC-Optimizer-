# Interactive menus (built automatically from the registered actions).
function Show-CategoryMenu([string]$Category) {
    while ($true) {
        Show-Banner
        Head $Category
        $acts = @($script:Actions | Where-Object { $_.Category -eq $Category })
        $i = 1
        foreach ($a in $acts) {
            $manual = if ($a.Manual) { ' (manual)' } else { '' }
            Write-Host ('  {0,2}) [{1}] {2}{3}' -f $i, (Get-TierTag $a.Tier), $a.Title, $manual) -ForegroundColor (Get-TierColor $a.Tier)
            Write-Host ('        ' + $a.Description) -ForegroundColor DarkGray
            $i++
        }
        Write-Host ''
        Write-Host '   numbers = run (e.g. 1,3)    a = run all Safe+Moderate (non-manual)    b = back' -ForegroundColor Gray
        $sel = (Read-Host '  Choose').Trim()
        if ($sel -eq '' -or $sel -match '^[bB0]$') { return }
        $queue = @()
        if ($sel -match '^[aA]$') {
            $queue = @($acts | Where-Object { $_.Tier -le 2 -and -not $_.Manual })
        } else {
            foreach ($n in ($sel -split '[,\s]+' | Where-Object { $_ -match '^\d+$' })) {
                $idx = [int]$n - 1
                if ($idx -ge 0 -and $idx -lt $acts.Count) { $queue += $acts[$idx] }
            }
        }
        if ($queue.Count -eq 0) { continue }
        if (@($queue | Where-Object { $_.Tier -ge 2 }).Count -gt 0) { New-RestorePoint }
        $script:Results.Clear()
        foreach ($a in $queue) { Invoke-Action $a }
        Show-Results
        Pause-Menu
    }
}

function Show-MainMenu {
    while ($true) {
        Show-Banner
        $cats = @(Get-Categories)
        Write-Host ''
        Write-Host '  PRESETS' -ForegroundColor White
        Write-Host '    S) Safe       low-risk tweaks only' -ForegroundColor Green
        Write-Host '    B) Balanced   Safe + moderate tweaks   (recommended)' -ForegroundColor Yellow
        Write-Host '    X) Extreme    everything non-manual    (advanced, asks first)' -ForegroundColor Red
        Write-Host ''
        Write-Host '  CATEGORIES' -ForegroundColor White
        $i = 1
        foreach ($c in $cats) {
            $n = @($script:Actions | Where-Object { $_.Category -eq $c }).Count
            Write-Host ('   {0,2}) {1,-12} {2} actions' -f $i, $c, $n)
            $i++
        }
        Write-Host ''
        Write-Host '    R) Before/after report    U) Undo ALL changes    L) Open logs    Q) Quit' -ForegroundColor Gray
        $c = (Read-Host '  Choose').Trim()
        try {
            switch -Regex ($c) {
                '^[qQ0]$' { return }
                '^[sS]$'  { $script:Results.Clear(); Invoke-Preset 'Safe';     Pause-Menu }
                '^[bB]$'  { $script:Results.Clear(); Invoke-Preset 'Balanced'; Pause-Menu }
                '^[xX]$'  { $script:Results.Clear(); Invoke-Preset 'Extreme';  Pause-Menu }
                '^[rR]$'  { Invoke-ByIds 'Diagnostics.Report'; Pause-Menu }
                '^[uU]$'  { Undo-All; Pause-Menu }
                '^[lL]$'  { Start-Process explorer.exe $script:LogDir }
                '^\d+$'   {
                    $idx = [int]$c - 1
                    if ($idx -ge 0 -and $idx -lt $cats.Count) { Show-CategoryMenu $cats[$idx] }
                }
            }
        } catch {
            Bad $_.Exception.Message
            Pause-Menu
        }
    }
}
