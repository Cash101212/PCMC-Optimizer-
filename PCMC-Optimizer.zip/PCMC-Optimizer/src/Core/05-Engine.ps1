# Action engine: modules register actions, the engine runs them (by id, category or profile).
#   Tier 1 = SAFE      low risk, fully reversible
#   Tier 2 = MODERATE  noticeable system changes, reversible
#   Tier 3 = ADVANCED  aggressive / hardware-dependent, always reversible but be deliberate
$script:Actions     = New-Object System.Collections.ArrayList
$script:Results     = New-Object System.Collections.ArrayList
$script:NeedsReboot = $false

function Register-Action {
    param(
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Id,
        [Parameter(Mandatory)][string]$Title,
        [string]$Description = '',
        [ValidateRange(1, 3)][int]$Tier = 1,
        [Parameter(Mandatory)][scriptblock]$Run,
        [switch]$Manual,   # never part of a profile run (interactive / diagnostic / slow)
        [switch]$Ask,      # always ask before running
        [switch]$Reboot,   # needs a restart to take effect
        [string]$Note = ''
    )
    [void]$script:Actions.Add([pscustomobject]@{
        Category = $Category; Id = $Id; Title = $Title; Description = $Description; Tier = $Tier
        Run = $Run; Manual = [bool]$Manual; Ask = [bool]$Ask; Reboot = [bool]$Reboot; Note = $Note
    })
}

function Get-Categories { @($script:Actions | Select-Object -ExpandProperty Category -Unique) }

function Add-Result($Action, [string]$Status) {
    [void]$script:Results.Add([pscustomobject]@{ Id = $Action.Id; Title = $Action.Title; Status = $Status })
}

function Invoke-Action {
    param($Action)
    $ErrorActionPreference = 'Stop'
    if (@($script:Config.ExcludeActions) -contains $Action.Id) {
        Info "Excluded in settings.json: $($Action.Id)"; Add-Result $Action 'excluded'; return
    }
    Write-Host ''
    Write-Host ('>> {0}  [{1}]' -f $Action.Title, $Action.Id) -ForegroundColor White
    if ($script:DryRun) {
        Info ('[dry-run] would run: ' + $Action.Description); Add-Result $Action 'dry-run'; return
    }
    if ($Action.Ask -and -not $script:Yes) {
        if ($Action.Note) { Warn $Action.Note }
        if (-not (Confirm-Action 'Run this step?' $false)) { Info 'Skipped.'; Add-Result $Action 'skipped'; return }
    }
    try {
        & $Action.Run
        if ($Action.Reboot) { $script:NeedsReboot = $true }
        Add-Result $Action 'done'
    } catch {
        Bad $_.Exception.Message
        Add-Result $Action 'FAILED'
    } finally {
        Save-Journal
    }
}

# Pattern may be an action id / wildcard (any action) or a category name (non-manual actions only).
function Find-Actions([string[]]$Pattern) {
    $found = @()
    foreach ($p in $Pattern) {
        $found += @($script:Actions | Where-Object { $_.Id -like $p })
        $found += @($script:Actions | Where-Object { $_.Category -like $p -and -not $_.Manual })
    }
    $found | Select-Object -Unique
}

function Show-Results {
    Head 'Summary'
    $script:Results | Group-Object Status | ForEach-Object {
        $color = switch ($_.Name) { 'done' { 'Green' } 'FAILED' { 'Red' } default { 'Yellow' } }
        Write-Host ('  {0,-9} {1}' -f $_.Name, $_.Count) -ForegroundColor $color
    }
    $failed = @($script:Results | Where-Object Status -eq 'FAILED')
    foreach ($f in $failed) { Bad "Failed: $($f.Id)" }
    if ($script:NeedsReboot) { Warn 'A restart is required for some changes to take effect.' }
    Info "Log file: $($script:LogFile)"
}

function Invoke-Preset {
    param([ValidateSet('Safe', 'Balanced', 'Extreme')][string]$Name)
    $level = @{ Safe = 1; Balanced = 2; Extreme = 3 }[$Name]
    Head "Preset: $Name"
    if ($level -ge 3 -and -not $script:Yes -and -not $script:DryRun) {
        Warn 'Extreme runs advanced tweaks (CPU parking, Nagle, timer resolution, service changes...).'
        Warn 'Everything is journaled and can be undone, but review docs\MODULES.md first.'
        if (-not (Confirm-Action 'Continue with Extreme?' $false)) { return }
    }
    New-RestorePoint
    if (Get-Command Save-Snapshot -ErrorAction SilentlyContinue) { Save-Snapshot 'before' | Out-Null }
    $queue = @($script:Actions | Where-Object { $_.Tier -le $level -and -not $_.Manual })
    Info "$($queue.Count) action(s) queued."
    foreach ($a in $queue) { Invoke-Action $a }
    if (Get-Command Save-Snapshot -ErrorAction SilentlyContinue) { Save-Snapshot 'after' | Out-Null }
    Show-Results
}

function Invoke-ByIds([string[]]$Ids) {
    $queue = @(Find-Actions $Ids)
    if ($queue.Count -eq 0) { Bad "No action matches: $($Ids -join ', ')  (use -List to see ids)"; return }
    if (@($queue | Where-Object { $_.Tier -ge 2 }).Count -gt 0) { New-RestorePoint }
    foreach ($a in $queue) { Invoke-Action $a }
    Show-Results
}

function Show-ActionList {
    foreach ($cat in (Get-Categories)) {
        Head $cat
        foreach ($a in @($script:Actions | Where-Object { $_.Category -eq $cat })) {
            $manual = if ($a.Manual) { '  (manual)' } else { '' }
            Write-Host ('  {0,-26} T{1}  {2}{3}' -f $a.Id, $a.Tier, $a.Title, $manual) -ForegroundColor (Get-TierColor $a.Tier)
        }
    }
}
