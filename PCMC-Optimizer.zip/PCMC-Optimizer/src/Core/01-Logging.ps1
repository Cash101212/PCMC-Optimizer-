# Console + file logging helpers.
function Log([string]$Message) {
    try { Add-Content -LiteralPath $script:LogFile -Value ('[{0:HH:mm:ss}] {1}' -f (Get-Date), $Message) } catch { }
}
function Ok([string]$Message)   { Write-Host "  [+] $Message" -ForegroundColor Green;  Log "OK   $Message" }
function Info([string]$Message) { Write-Host "  [i] $Message" -ForegroundColor Cyan;   Log "INFO $Message" }
function Warn([string]$Message) { Write-Host "  [!] $Message" -ForegroundColor Yellow; Log "WARN $Message" }
function Bad([string]$Message)  { Write-Host "  [x] $Message" -ForegroundColor Red;    Log "FAIL $Message" }
function Head([string]$Message) {
    Write-Host ''
    Write-Host ("== {0} ==" -f $Message) -ForegroundColor Magenta
    Log "---- $Message"
}
function Remove-OldLogs {
    $cutoff = (Get-Date).AddDays(-[int]$script:Config.LogRetentionDays)
    Get-ChildItem -LiteralPath $script:LogDir -Filter '*.log' -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        Remove-Item -Force -ErrorAction SilentlyContinue
}
