# Banner and prompt helpers.
function Show-Banner {
    Clear-Host
    $mode = if ($script:DryRun) { 'DRY RUN - nothing is changed' } else { 'live mode' }
    Write-Host ''
    Write-Host '  ================================================================' -ForegroundColor Cyan
    Write-Host '    PCMC OPTIMIZER  -  Windows + Minecraft performance toolkit' -ForegroundColor Cyan
    Write-Host ("    v{0}   [{1}]" -f $script:Version, $mode) -ForegroundColor DarkCyan
    Write-Host '  ================================================================' -ForegroundColor Cyan
}

function Confirm-Action([string]$Question, [bool]$Default = $true) {
    if ($script:Yes) { return $Default }
    $hint = if ($Default) { 'Y/n' } else { 'y/N' }
    $a = Read-Host "  $Question [$hint]"
    if ([string]::IsNullOrWhiteSpace($a)) { return $Default }
    return ($a -match '^(y|yes)$')
}

function Pause-Menu {
    if (-not $script:NonInteractive) { Read-Host '  Press Enter to continue' | Out-Null }
}

function Get-TierTag([int]$Tier) {
    switch ($Tier) { 1 { 'SAFE' } 2 { 'MOD ' } default { 'ADV ' } }
}
function Get-TierColor([int]$Tier) {
    switch ($Tier) { 1 { 'Green' } 2 { 'Yellow' } default { 'Red' } }
}
