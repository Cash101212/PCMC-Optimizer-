# Global paths, version and user configuration (config\settings.json).
$script:Version     = '2.0.0'
$script:DataDir     = Join-Path $env:USERPROFILE 'PCMC-Optimizer'
$script:BackupDir   = Join-Path $script:DataDir 'backups'
$script:ReportDir   = Join-Path $script:DataDir 'reports'
$script:LogDir      = Join-Path $script:DataDir 'logs'
$script:JournalFile = Join-Path $script:DataDir 'journal.json'
$script:LogFile     = Join-Path $script:LogDir ('{0:yyyy-MM-dd}.log' -f (Get-Date))

foreach ($d in @($script:DataDir, $script:BackupDir, $script:ReportDir, $script:LogDir)) {
    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

$script:Config = [pscustomobject]@{
    MinecraftDir       = $null
    RamAllocationGB    = $null
    RenderDistance     = $null
    SimulationDistance = $null
    DnsProvider        = 'Cloudflare'
    ExcludeActions     = @()
    LogRetentionDays   = 14
}

$cfgPath = Join-Path $script:RepoRoot 'config\settings.json'
if (Test-Path -LiteralPath $cfgPath) {
    try {
        $user = Get-Content -LiteralPath $cfgPath -Raw | ConvertFrom-Json
        foreach ($p in $user.PSObject.Properties) {
            if ($p.Name -notlike '_*') {
                $script:Config | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value -Force
            }
        }
    } catch {
        Write-Host '  [!] config\settings.json is invalid JSON - using defaults.' -ForegroundColor Yellow
    }
}
