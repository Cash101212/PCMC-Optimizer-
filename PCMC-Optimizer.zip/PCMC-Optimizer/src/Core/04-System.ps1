# Shared helpers: admin check, registry writes (journaled), system facts, file helpers.
$script:GuidRx = '[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}'

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Format-Bytes([double]$Bytes) {
    if ($Bytes -ge 1GB) { return ('{0:N2} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:N1} MB' -f ($Bytes / 1MB)) }
    return ('{0:N0} KB' -f ($Bytes / 1KB))
}

function Set-Reg {
    param([string]$Path, [string]$Name, $Value, [string]$Type = 'DWord')
    if ($script:DryRun) { Info "[dry-run] $Path\$Name = $Value"; return $true }
    try {
        if (-not (Test-Path -LiteralPath $Path)) { New-Item -Path $Path -Force | Out-Null }
        $existing = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction SilentlyContinue
        $old = $null; $kind = $null
        if ($null -ne $existing) {
            $old  = $existing.$Name
            $kind = (Get-Item -LiteralPath $Path).GetValueKind($Name).ToString()
        }
        Add-Journal @{ Type = 'Registry'; Path = $Path; Name = $Name; Existed = ($null -ne $existing); Old = $old; OldType = $kind }
        Set-ItemProperty -LiteralPath $Path -Name $Name -Value $Value -Type $Type -Force -ErrorAction Stop
        Log "REG  $Path\$Name = $Value"
        return $true
    } catch {
        Bad ("Registry write failed ({0}\{1}): {2}" -f $Path, $Name, $_.Exception.Message)
        return $false
    }
}

function Get-SystemSummary {
    if ($script:SysCache) { return $script:SysCache }
    $os  = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $gpu = @(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic|Remote|Virtual' })
    $isSsd = $false
    try {
        $disk = Get-Partition -DriveLetter ($env:SystemDrive.Substring(0, 1)) | Get-Disk
        $pd = Get-PhysicalDisk | Where-Object { [string]$_.DeviceId -eq [string]$disk.Number } | Select-Object -First 1
        $isSsd = ($pd.MediaType -eq 'SSD')
    } catch { }
    $script:SysCache = [pscustomobject]@{
        OS        = $os.Caption
        Build     = $os.BuildNumber
        CPU       = $cpu.Name.Trim()
        Cores     = $cpu.NumberOfCores
        Threads   = $cpu.NumberOfLogicalProcessors
        GPU       = (($gpu | ForEach-Object { $_.Name }) -join ', ')
        RamGB     = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
        IsSsd     = $isSsd
        IsLaptop  = [bool](Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
        IsWin11   = ([int]$os.BuildNumber -ge 22000)
    }
    return $script:SysCache
}

function Get-FolderSize([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return 0 }
    $sum = (Get-ChildItem -LiteralPath $Path -Recurse -Force -File -ErrorAction SilentlyContinue |
            Measure-Object -Property Length -Sum).Sum
    return [double]$sum
}

# Deletes the CONTENTS of a folder; returns bytes freed.
function Clear-Folder([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return 0 }
    $before = Get-FolderSize $Path
    Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    $after = Get-FolderSize $Path
    return [math]::Max(0, $before - $after)
}

# Copies a file into the backup folder and records it in the journal.
function Backup-File([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $tag  = [guid]::NewGuid().ToString('N').Substring(0, 6)
    $dest = Join-Path $script:BackupDir ('{0:yyyyMMdd-HHmmss}-{1}-{2}' -f (Get-Date), $tag, (Split-Path $Path -Leaf))
    Copy-Item -LiteralPath $Path -Destination $dest -Force
    Add-Journal @{ Type = 'File'; Original = $Path; Backup = $dest }
    return $dest
}

function Write-TextNoBom([string]$Path, [string]$Text) {
    [System.IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding $false))
}

function New-RestorePoint {
    if ($script:NoRestorePoint -or $script:DryRun) { Info 'Restore point skipped.'; return }
    $key = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    try {
        Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
        Set-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
        Checkpoint-Computer -Description 'PCMC-Optimizer' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Ok 'System restore point created.'
    } catch {
        Warn "Could not create a restore point: $($_.Exception.Message)"
        if ($script:Yes) { Warn 'Continuing (-Yes).' }
        elseif (-not (Confirm-Action 'Continue without a restore point?' $false)) { throw 'Cancelled by user.' }
    } finally {
        Remove-ItemProperty -Path $key -Name 'SystemRestorePointCreationFrequency' -ErrorAction SilentlyContinue
    }
}
