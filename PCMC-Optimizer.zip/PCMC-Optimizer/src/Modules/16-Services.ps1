# Category: Services  -  disable background services that are not needed for gaming/desktop use.
# Start-type changes go through Set-Reg, so Undo restores them exactly.
# NOT touched on purpose: Xbox services (needed for Game Pass / Bedrock sign-in), Windows Update, Defender, Audio, Bluetooth.

function Disable-ServiceSafe([string]$Name, [string]$Label) {
    $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
    if (-not (Test-Path -LiteralPath $key)) { Info "$Label ($Name) not present - skipped."; return }
    if (Set-Reg $key 'Start' 4) {
        Stop-Service -Name $Name -Force -ErrorAction SilentlyContinue
        Ok "Disabled: $Label ($Name)"
    }
}

Register-Action -Category 'Services' -Id 'Services.Telemetry' -Tier 2 -Title 'Disable telemetry services' -Description 'Connected User Experiences and Telemetry (DiagTrack) + WAP push routing.' -Run {
    Disable-ServiceSafe 'DiagTrack' 'Connected User Experiences and Telemetry'
    Disable-ServiceSafe 'dmwappushservice' 'WAP Push Message Routing'
}

Register-Action -Category 'Services' -Id 'Services.Unneeded' -Tier 3 -Title 'Disable rarely-used services' -Description 'Downloaded Maps Manager, Retail Demo, Fax, Windows Media Player sharing, Geolocation.' -Run {
    Disable-ServiceSafe 'MapsBroker' 'Downloaded Maps Manager'
    Disable-ServiceSafe 'RetailDemo' 'Retail Demo Service'
    Disable-ServiceSafe 'Fax' 'Fax'
    Disable-ServiceSafe 'WMPNetworkSvc' 'Windows Media Player Network Sharing'
    Disable-ServiceSafe 'lfsvc' 'Geolocation Service'
}
