# Category: Minecraft  -  manual tools: mod installer, world backup, Java info.

Register-Action -Category 'Minecraft' -Id 'Minecraft.Mods' -Tier 2 -Manual -Title 'Install FPS mods from Modrinth (Fabric)' -Description 'Downloads Sodium, Lithium, FerriteCore, ModernFix, Entity Culling, Iris + Fabric API with hash verification.' -Run {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $dirs = @(Get-McGameDirs)
    if ($dirs.Count -eq 0) { $dirs = @(Get-McDir) }
    for ($i = 0; $i -lt $dirs.Count; $i++) { Write-Host ("   {0}) {1}" -f ($i + 1), $dirs[$i]) }
    $pick = Read-Host '  Install into which game folder? (number)'
    if ($pick -notmatch '^\d+$' -or [int]$pick -lt 1 -or [int]$pick -gt $dirs.Count) { Warn 'Cancelled.'; return }
    $gameDir = $dirs[[int]$pick - 1]
    $mcv = (Read-Host '  Minecraft version (e.g. 1.21.4)').Trim()
    if ($mcv -notmatch '^\d+\.\d+(\.\d+)?$') { Warn 'Invalid version.'; return }

    $modsDir = Join-Path $gameDir 'mods'
    if (-not (Test-Path -LiteralPath $modsDir)) { New-Item -ItemType Directory -Path $modsDir -Force | Out-Null }
    $headers = @{ 'User-Agent' = "PCMC-Optimizer/$($script:Version) (github.com)" }
    $gv = [uri]::EscapeDataString('["' + $mcv + '"]')
    $ld = [uri]::EscapeDataString('["fabric"]')

    foreach ($slug in 'fabric-api', 'sodium', 'lithium', 'ferrite-core', 'modernfix', 'entityculling', 'iris') {
        try {
            $vers = @(Invoke-RestMethod -Uri "https://api.modrinth.com/v2/project/$slug/version?game_versions=$gv&loaders=$ld" -Headers $headers)
            $v = $vers | Where-Object { $_.version_type -eq 'release' } | Select-Object -First 1
            if (-not $v) { $v = $vers | Select-Object -First 1 }
            if (-not $v) { Warn "$slug has no Fabric build for $mcv - skipped."; continue }
            $file = $v.files | Where-Object { $_.primary } | Select-Object -First 1
            if (-not $file) { $file = $v.files | Select-Object -First 1 }
            $dest = Join-Path $modsDir $file.filename
            Invoke-WebRequest -Uri $file.url -OutFile $dest -UseBasicParsing -Headers $headers
            $hash = (Get-FileHash -LiteralPath $dest -Algorithm SHA512).Hash
            if ($hash -ieq $file.hashes.sha512) { Ok "$slug  ->  $($file.filename)" }
            else { Remove-Item -LiteralPath $dest -Force; Bad "$slug hash mismatch - file deleted." }
        } catch { Bad "$slug failed: $($_.Exception.Message)" }
    }
    Info 'You still need the Fabric loader installed for this version (fabricmc.net/use).'
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.BackupWorlds' -Tier 1 -Manual -Title 'Back up all worlds (zip)' -Description 'Zips .minecraft\saves into the PCMC backups folder.' -Run {
    $saves = Join-Path (Get-McDir) 'saves'
    if (-not (Test-Path -LiteralPath $saves)) { Warn 'No saves folder found.'; return }
    $zip = Join-Path $script:BackupDir ('worlds-{0:yyyyMMdd-HHmmss}.zip' -f (Get-Date))
    Compress-Archive -Path (Join-Path $saves '*') -DestinationPath $zip -CompressionLevel Optimal
    Ok ("Worlds backed up: {0} ({1})" -f $zip, (Format-Bytes (Get-Item -LiteralPath $zip).Length))
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.JavaInfo' -Tier 1 -Manual -Title 'Show Java runtimes and recommendations' -Description 'Lists Minecraft bundled runtimes and which Java version your game version needs.' -Run {
    $names = @{
        'java-runtime-alpha' = 'Java 16 (1.17)'; 'java-runtime-beta' = 'Java 17 (early)'; 'java-runtime-gamma' = 'Java 17 (1.18 - 1.20.4)'
        'java-runtime-gamma-snapshot' = 'Java 17 (snapshots)'; 'java-runtime-delta' = 'Java 21 (1.20.5+)'; 'java-runtime-epsilon' = 'newer than Java 21 (latest versions)'
    }
    $rt = Join-Path (Get-McDir) 'runtime'
    if (Test-Path -LiteralPath $rt) {
        foreach ($d in @(Get-ChildItem -LiteralPath $rt -Directory -ErrorAction SilentlyContinue)) {
            $label = if ($names.ContainsKey($d.Name)) { $names[$d.Name] } else { 'unknown' }
            Write-Host ('   {0,-30} {1}' -f $d.Name, $label)
        }
    } else { Info 'No bundled runtime folder found.' }
    Write-Host ''
    Write-Host '   Recommended Java: 1.21+ -> 21 | 1.18-1.20.4 -> 17 | 1.17 -> 16 | 1.16 and older -> 8' -ForegroundColor Cyan
    $j = Get-Command java -ErrorAction SilentlyContinue
    if ($j) { Info "java on PATH: $($j.Source)" }
}
