# Category: Visuals  -  a sleek, snappy desktop without hurting usability.

Register-Action -Category 'Visuals' -Id 'Visuals.Transparency' -Tier 1 -Title 'Turn off transparency effects' -Description 'Removes acrylic/blur effects (saves GPU time, cleaner look).' -Run {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' 'EnableTransparency' 0 | Out-Null
    Ok 'Transparency off.'
}

Register-Action -Category 'Visuals' -Id 'Visuals.Animations' -Tier 1 -Title 'Snappier animations and menus' -Description 'Disables window min/max animation and cuts menu delay to 50 ms.' -Run {
    Set-Reg 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '50' 'String' | Out-Null
    Set-Reg 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String' | Out-Null
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarAnimations' 0 | Out-Null
    Ok 'Animations trimmed.'
}

Register-Action -Category 'Visuals' -Id 'Visuals.SleekTaskbar' -Tier 2 -Title 'Clean taskbar (hide widgets, chat, task view, search box)' -Description 'Minimal taskbar: removes the clutter buttons. Some keys are protected on newer Win11 builds.' -Run {
    $adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    Set-Reg $adv 'ShowTaskViewButton' 0 | Out-Null
    Set-Reg $adv 'TaskbarDa' 0 | Out-Null
    Set-Reg $adv 'TaskbarMn' 0 | Out-Null
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0 | Out-Null
    Ok 'Taskbar decluttered (sign out/in or restart Explorer to see it).'
}

Register-Action -Category 'Visuals' -Id 'Visuals.Explorer' -Tier 2 -Title 'Cleaner File Explorer' -Description 'Opens to This PC, shows file extensions, hides OneDrive/sync promo banners.' -Run {
    $adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    Set-Reg $adv 'LaunchTo' 1 | Out-Null
    Set-Reg $adv 'HideFileExt' 0 | Out-Null
    Set-Reg $adv 'ShowSyncProviderNotifications' 0 | Out-Null
    Ok 'Explorer cleaned up.'
}

Register-Action -Category 'Visuals' -Id 'Visuals.DarkMode' -Tier 2 -Ask -Title 'Dark mode for apps and system' -Description 'Switches Windows and apps to the dark theme.' -Note 'Purely cosmetic.' -Run {
    $p = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
    Set-Reg $p 'AppsUseLightTheme' 0 | Out-Null
    Set-Reg $p 'SystemUsesLightTheme' 0 | Out-Null
    Ok 'Dark mode enabled.'
}
