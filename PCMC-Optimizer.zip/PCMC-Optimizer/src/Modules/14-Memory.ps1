# Category: Memory  -  RAM behaviour. (No fake "RAM cleaners": clearing working sets just causes page faults.)

Register-Action -Category 'Memory' -Id 'Memory.KeepKernelInRam' -Tier 3 -Reboot -Title 'Keep kernel/drivers in RAM (DisablePagingExecutive)' -Description 'Prevents core Windows code being paged out. Only applied on systems with 16 GB+ RAM.' -Run {
    $ram = (Get-SystemSummary).RamGB
    if ($ram -lt 16) { Warn "Skipped: only $ram GB RAM (needs 16 GB+)."; return }
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' 'DisablePagingExecutive' 1 | Out-Null
    Ok 'Kernel pinned in RAM (restart required).'
}

Register-Action -Category 'Memory' -Id 'Memory.SysMain' -Tier 3 -Title 'Disable SysMain (Superfetch) service' -Description 'Stops background prefetching. Useful on SSD systems; keep it on if you still use a hard drive.' -Run {
    if (-not (Get-SystemSummary).IsSsd) { Warn 'Skipped: system drive is not detected as SSD (SysMain helps HDDs).'; return }
    if (Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Services\SysMain' 'Start' 4) {
        Stop-Service -Name SysMain -Force -ErrorAction SilentlyContinue
        Ok 'SysMain disabled.'
    }
}
