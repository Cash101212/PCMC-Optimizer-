# Category: Gaming  -  Game Mode, capture overhead, scheduling, input and GPU settings.

Register-Action -Category 'Gaming' -Id 'Gaming.GameMode' -Tier 1 -Title 'Enable Game Mode' -Description 'Prioritises the foreground game and suppresses Windows Update interruptions.' -Run {
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1 | Out-Null
    Set-Reg 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1 | Out-Null
    Ok 'Game Mode enabled.'
}

Register-Action -Category 'Gaming' -Id 'Gaming.DisableCapture' -Tier 1 -Title 'Disable background game capture (Game DVR)' -Description 'Removes the background recording overhead of Xbox Game Bar capture.' -Run {
    Set-Reg 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0 | Out-Null
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0 | Out-Null
    Ok 'Background capture disabled (Game Bar overlay still works).'
}

Register-Action -Category 'Gaming' -Id 'Gaming.MouseAccel' -Tier 2 -Title 'Disable mouse acceleration' -Description 'Turns off Enhance pointer precision for consistent 1:1 aim (applies after sign-out).' -Run {
    Set-Reg 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '0' 'String' | Out-Null
    Set-Reg 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '0' 'String' | Out-Null
    Set-Reg 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '0' 'String' | Out-Null
    Ok 'Mouse acceleration disabled.'
}

Register-Action -Category 'Gaming' -Id 'Gaming.FullscreenOpt' -Tier 2 -Title 'Prefer true exclusive fullscreen' -Description 'Disables fullscreen-optimization behaviour that can add input latency in some games.' -Run {
    $p = 'HKCU:\System\GameConfigStore'
    Set-Reg $p 'GameDVR_FSEBehaviorMode' 2 | Out-Null
    Set-Reg $p 'GameDVR_HonorUserFSEBehaviorMode' 1 | Out-Null
    Set-Reg $p 'GameDVR_DXGIHonorFSEWindowsCompatible' 1 | Out-Null
    Ok 'Fullscreen behaviour set to exclusive-friendly.'
}

Register-Action -Category 'Gaming' -Id 'Gaming.MmcssGames' -Tier 2 -Title 'Raise MMCSS game scheduling priority' -Description 'Gives the Games scheduling class higher GPU/CPU priority and tightens system responsiveness.' -Run {
    $t = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'
    Set-Reg $t 'GPU Priority' 8 | Out-Null
    Set-Reg $t 'Priority' 6 | Out-Null
    Set-Reg $t 'Scheduling Category' 'High' 'String' | Out-Null
    Set-Reg $t 'SFIO Priority' 'High' 'String' | Out-Null
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' 'SystemResponsiveness' 10 | Out-Null
    Ok 'MMCSS Games profile boosted.'
}

Register-Action -Category 'Gaming' -Id 'Gaming.Hags' -Tier 2 -Ask -Reboot -Title 'Hardware-accelerated GPU scheduling (HAGS)' -Description 'Lets the GPU manage its own memory scheduling. Needs a recent GPU + driver (restart required).' -Note 'Helps on newer NVIDIA/AMD GPUs; older GPUs may see no benefit.' -Run {
    if (Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2) { Ok 'HAGS enabled (restart required).' }
}

Register-Action -Category 'Gaming' -Id 'Gaming.Win32Priority' -Tier 3 -Title 'Foreground boost: short quanta (Win32PrioritySeparation)' -Description 'Sets the CPU scheduler to favour foreground apps/games (value 0x26).' -Run {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 38 | Out-Null
    Ok 'Foreground scheduling boost applied.'
}

Register-Action -Category 'Gaming' -Id 'Gaming.TimerResolution' -Tier 3 -Reboot -Title 'Global timer resolution requests (Win10 2004+/Win11)' -Description 'Honours per-process high-resolution timer requests system-wide (smoother frame pacing).' -Run {
    Set-Reg 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel' 'GlobalTimerResolutionRequests' 1 | Out-Null
    Ok 'Global timer resolution requests enabled (restart required).'
}
