# Category: Privacy  -  stop Windows promos, ad tracking and background telemetry. Light-touch, no hard blocking.

Register-Action -Category 'Privacy' -Id 'Privacy.AdvertisingId' -Tier 1 -Title 'Disable advertising ID' -Description 'Stops per-user ad profiling across apps.' -Run {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0 | Out-Null
    Ok 'Advertising ID disabled.'
}

Register-Action -Category 'Privacy' -Id 'Privacy.Suggestions' -Tier 1 -Title 'Remove Start / lock screen promotions' -Description 'Disables suggested apps, silent app installs, tips and "fun facts".' -Run {
    $p = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
    foreach ($n in 'SubscribedContent-338388Enabled', 'SubscribedContent-338389Enabled', 'SubscribedContent-310093Enabled',
                   'SubscribedContent-338393Enabled', 'SubscribedContent-353694Enabled', 'SubscribedContent-353696Enabled',
                   'SilentInstalledAppsEnabled', 'SystemPaneSuggestionsEnabled', 'RotatingLockScreenOverlayEnabled', 'SoftLandingEnabled') {
        Set-Reg $p $n 0 | Out-Null
    }
    Ok 'Promotions and suggestions disabled.'
}

Register-Action -Category 'Privacy' -Id 'Privacy.WebSearch' -Tier 1 -Title 'Disable web results in Start search' -Description 'Start search stays local and faster (no Bing suggestions).' -Run {
    Set-Reg 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1 | Out-Null
    Ok 'Web search suggestions disabled (sign out/in to apply).'
}

Register-Action -Category 'Privacy' -Id 'Privacy.Telemetry' -Tier 2 -Title 'Reduce telemetry to minimum' -Description 'Sets diagnostic data to the lowest level allowed on your edition.' -Run {
    Set-Reg 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry' 1 | Out-Null
    Ok 'Telemetry reduced.'
}

Register-Action -Category 'Privacy' -Id 'Privacy.ActivityHistory' -Tier 2 -Title 'Disable activity history / timeline upload' -Description 'Stops Windows collecting and syncing your activity history.' -Run {
    $p = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'
    Set-Reg $p 'EnableActivityFeed' 0 | Out-Null
    Set-Reg $p 'PublishUserActivities' 0 | Out-Null
    Set-Reg $p 'UploadUserActivities' 0 | Out-Null
    Ok 'Activity history disabled.'
}
