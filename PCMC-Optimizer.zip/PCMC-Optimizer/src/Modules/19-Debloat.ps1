# Category: Debloat  -  remove preinstalled apps you pick. Protected apps (Store, Xbox, Photos, Calculator, Terminal...) are never listed.
# Removal is not journaled: reinstall any app from the Microsoft Store.
$script:BloatPatterns = @(
    'Microsoft.BingNews', 'Microsoft.BingWeather', 'Microsoft.BingFinance', 'Microsoft.BingSports', 'Microsoft.GetHelp',
    'Microsoft.Getstarted', 'Microsoft.MicrosoftSolitaireCollection', 'Microsoft.MixedReality.Portal', 'Microsoft.People',
    'Microsoft.SkypeApp', 'Microsoft.WindowsFeedbackHub', 'Microsoft.YourPhone', 'Microsoft.ZuneMusic', 'Microsoft.ZuneVideo',
    'Clipchamp.Clipchamp', 'MicrosoftTeams', 'Microsoft.549981C3F5F10', 'Microsoft.MicrosoftOfficeHub', 'Microsoft.Todos',
    'Microsoft.PowerAutomateDesktop', 'Microsoft.WindowsMaps', '*CandyCrush*', '*SpotifyAB*', '*Disney*', '*TikTok*',
    '*Facebook*', '*Instagram*', '*LinkedIn*', 'Microsoft.OutlookForWindows'
)

Register-Action -Category 'Debloat' -Id 'Debloat.Apps' -Tier 3 -Manual -Title 'Remove preinstalled apps (pick from list)' -Description 'Shows installed bloat candidates; you choose which to remove. Reinstall from the Store anytime.' -Run {
    if ($PSVersionTable.PSVersion.Major -ge 7) { Import-Module Appx -UseWindowsPowerShell -WarningAction SilentlyContinue }
    $found = @()
    foreach ($pat in $script:BloatPatterns) {
        $found += @(Get-AppxPackage -Name $pat -ErrorAction SilentlyContinue | Where-Object { -not $_.NonRemovable })
    }
    $found = @($found | Sort-Object PackageFullName -Unique)
    if ($found.Count -eq 0) { Info 'No bloat candidates found - your system is already clean.'; return }
    $i = 1
    foreach ($p in $found) { Write-Host ('  {0,2}) {1}' -f $i, $p.Name); $i++ }
    $sel = Read-Host "`n  Numbers to remove (e.g. 1,4), 'all' or Enter to skip"
    if ([string]::IsNullOrWhiteSpace($sel)) { return }
    $targets = if ($sel -match '^(all|a)$') { $found } else {
        @($sel -split '[,\s]+' | Where-Object { $_ -match '^\d+$' } | ForEach-Object { $idx = [int]$_ - 1; if ($idx -ge 0 -and $idx -lt $found.Count) { $found[$idx] } })
    }
    foreach ($p in $targets) {
        try { Remove-AppxPackage -Package $p.PackageFullName -ErrorAction Stop; Ok "Removed: $($p.Name)" }
        catch { Bad "Could not remove $($p.Name): $($_.Exception.Message)" }
    }
}
