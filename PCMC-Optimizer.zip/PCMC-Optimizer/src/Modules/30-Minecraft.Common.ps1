# Minecraft helpers shared by the Minecraft.* actions (no actions registered here).

function Get-McDir {
    if ($script:Config.MinecraftDir) { return [string]$script:Config.MinecraftDir }
    return (Join-Path $env:APPDATA '.minecraft')
}

function Test-McRunning {
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        ($_.ProcessName -match '^javaw?$' -and $_.MainWindowTitle -like 'Minecraft*') -or
        $_.ProcessName -match '^(Minecraft\.Windows|MinecraftLauncher)$'
    })
    return ($procs.Count -gt 0)
}

# options.txt of the official launcher + common third-party launcher instances
function Get-McOptionFiles {
    $files = @()
    $official = Join-Path (Get-McDir) 'options.txt'
    if (Test-Path -LiteralPath $official) { $files += $official }
    $roots = @(
        "$env:APPDATA\PrismLauncher\instances", "$env:APPDATA\PolyMC\instances", "$env:APPDATA\MultiMC\instances",
        "$env:USERPROFILE\curseforge\minecraft\Instances", "$env:APPDATA\ModrinthApp\profiles",
        "$env:APPDATA\com.modrinth.theseus\profiles", "$env:APPDATA\ATLauncher\instances"
    )
    foreach ($r in $roots) {
        if (Test-Path -LiteralPath $r) {
            $files += @(Get-ChildItem -LiteralPath $r -Filter 'options.txt' -Recurse -Depth 3 -File -ErrorAction SilentlyContinue |
                        Select-Object -ExpandProperty FullName)
        }
    }
    return @($files | Select-Object -Unique)
}

function Get-McGameDirs { @(Get-McOptionFiles | ForEach-Object { Split-Path $_ -Parent } | Select-Object -Unique) }

function Get-McRamGB {
    if ($script:Config.RamAllocationGB) { return [int]$script:Config.RamAllocationGB }
    $ram = (Get-SystemSummary).RamGB
    if ($ram -le 8)  { return 3 }
    if ($ram -le 16) { return 4 }
    if ($ram -le 32) { return 6 }
    return 8
}

# Aikar-style G1GC flags (well-tested for Minecraft clients), sized to your RAM.
function Get-JvmFlags {
    $g = Get-McRamGB
    return (@(
        "-Xms${g}G", "-Xmx${g}G", '-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200',
        '-XX:+UnlockExperimentalVMOptions', '-XX:+DisableExplicitGC', '-XX:+AlwaysPreTouch',
        '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M',
        '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4',
        '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90',
        '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:+PerfDisableSharedMem',
        '-XX:MaxTenuringThreshold=1'
    ) -join ' ')
}

function Find-Javaw {
    $roots = @(
        (Join-Path (Get-McDir) 'runtime'),
        "$env:LOCALAPPDATA\Packages\Microsoft.4297127D64EC6_8wekyb3d8bbwe\LocalCache\Local\runtime",
        "${env:ProgramFiles(x86)}\Minecraft Launcher\runtime",
        "$env:ProgramFiles\Java", "$env:ProgramFiles\Eclipse Adoptium", "$env:ProgramFiles\Microsoft",
        "$env:APPDATA\PrismLauncher\java", "$env:USERPROFILE\curseforge\minecraft\Install\runtime"
    )
    $out = @()
    foreach ($r in $roots) {
        if (Test-Path -LiteralPath $r) {
            $out += @(Get-ChildItem -LiteralPath $r -Filter 'javaw.exe' -Recurse -File -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
        }
    }
    return @($out | Select-Object -Unique)
}
