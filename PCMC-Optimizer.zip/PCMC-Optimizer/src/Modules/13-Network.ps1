# Category: Network  -  latency and stability tweaks, DNS.

Register-Action -Category 'Network' -Id 'Network.FlushDns' -Tier 1 -Title 'Flush DNS cache' -Description 'Clears stale DNS entries.' -Run {
    Clear-DnsClientCache
    Ok 'DNS cache flushed.'
}

Register-Action -Category 'Network' -Id 'Network.TcpDefaults' -Tier 2 -Title 'Healthy TCP stack (RSS on, auto-tuning normal)' -Description 'Ensures receive-side scaling and normal auto-tuning (repairs values broken by other tweak tools).' -Run {
    & netsh int tcp set global rss=enabled | Out-Null
    & netsh int tcp set global autotuninglevel=normal | Out-Null
    Ok 'TCP globals set to recommended values.'
}

Register-Action -Category 'Network' -Id 'Network.DeliveryOpt' -Tier 2 -Title 'Stop Windows Update peer-to-peer uploads' -Description 'Delivery Optimization will download from Microsoft only (no upload bandwidth used).' -Run {
    Set-Reg 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config' 'DODownloadMode' 0 | Out-Null
    Ok 'Delivery Optimization limited to HTTP only.'
}

Register-Action -Category 'Network' -Id 'Network.NagleOff' -Tier 3 -Title 'Disable Nagle / delayed ACK on active adapters' -Description 'Sets TcpAckFrequency=1 and TCPNoDelay=1 per interface: lower latency for small packets (games).' -Run {
    $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
    $n = 0
    foreach ($na in @(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' })) {
        $p = Join-Path $root $na.InterfaceGuid
        if (Test-Path -LiteralPath $p) {
            Set-Reg $p 'TcpAckFrequency' 1 | Out-Null
            Set-Reg $p 'TCPNoDelay' 1 | Out-Null
            $n++
        }
    }
    Ok "Nagle disabled on $n adapter(s) (restart or reconnect to apply)."
}

Register-Action -Category 'Network' -Id 'Network.Dns' -Tier 3 -Manual -Title 'Switch DNS provider (Cloudflare / Google / Quad9)' -Description 'Sets a fast public DNS on active adapters. Previous servers are restored by Undo.' -Run {
    $providers = [ordered]@{
        Cloudflare = @('1.1.1.1', '1.0.0.1')
        Google     = @('8.8.8.8', '8.8.4.4')
        Quad9      = @('9.9.9.9', '149.112.112.112')
    }
    $names = @($providers.Keys)
    for ($i = 0; $i -lt $names.Count; $i++) { Write-Host ("   {0}) {1}  {2}" -f ($i + 1), $names[$i], ($providers[$names[$i]] -join ', ')) }
    $pick = Read-Host "  Choose provider (1-$($names.Count)), Enter = $($script:Config.DnsProvider)"
    $chosen = if ($pick -match '^\d+$' -and [int]$pick -ge 1 -and [int]$pick -le $names.Count) { $names[[int]$pick - 1] } else { [string]$script:Config.DnsProvider }
    if (-not $providers.Contains($chosen)) { throw "Unknown DNS provider: $chosen" }
    foreach ($na in @(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' })) {
        $old = @((Get-DnsClientServerAddress -InterfaceIndex $na.ifIndex -AddressFamily IPv4).ServerAddresses)
        Add-Journal @{ Type = 'Dns'; Index = $na.ifIndex; OldServers = $old }
        Set-DnsClientServerAddress -InterfaceIndex $na.ifIndex -ServerAddresses $providers[$chosen]
        Ok "$($na.Name): DNS -> $chosen"
    }
    Clear-DnsClientCache
}
