# Category: Minecraft  -  OS-level integration for Java Edition.

Register-Action -Category 'Minecraft' -Id 'Minecraft.Gpu' -Tier 1 -Title 'Force high-performance GPU for Minecraft Java' -Description 'Assigns your dedicated GPU to every detected javaw.exe (important on laptops / hybrid graphics).' -Run {
    $paths = @(Find-Javaw)
    if ($paths.Count -eq 0) { Warn 'No javaw.exe found. Launch Minecraft once so its runtime downloads, then retry.'; return }
    foreach ($p in $paths) {
        if (Set-Reg 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences' $p 'GpuPreference=2;' 'String') { Ok "High-performance GPU: $p" }
    }
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.CpuPriority' -Tier 2 -Ask -Title 'Launch javaw.exe at High CPU priority' -Description 'Persistent High priority for Java via Image File Execution Options.' -Note 'Affects every Java app that uses javaw.exe, not only Minecraft.' -Run {
    $k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\javaw.exe\PerfOptions'
    if (Set-Reg $k 'CpuPriorityClass' 3) { Ok 'javaw.exe will start with High priority.' }
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.Defender' -Tier 3 -Ask -Title 'Defender exclusion for .minecraft' -Description 'Faster world/chunk IO and mod loading by skipping real-time scans of the game folder.' -Note 'Small security trade-off: files in this folder are no longer scanned in real time.' -Run {
    $dir = Get-McDir
    if (-not (Test-Path -LiteralPath $dir)) { Warn '.minecraft folder not found.'; return }
    Add-MpPreference -ExclusionPath $dir -ErrorAction Stop
    Add-Journal @{ Type = 'Command'; Exe = 'powershell.exe'; ExeArgs = @('-NoProfile', '-Command', "Remove-MpPreference -ExclusionPath '$dir'") }
    Ok "Defender exclusion added: $dir"
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.Cleanup' -Tier 1 -Title 'Clean logs, crash reports and web cache' -Description 'Removes old logs, crash reports and launcher web cache (saves, mods and configs untouched).' -Run {
    $mc = Get-McDir
    if (-not (Test-Path -LiteralPath $mc)) { Warn '.minecraft folder not found.'; return }
    $total = 0
    foreach ($sub in 'logs', 'crash-reports', 'webcache', 'webcache2') { $total += Clear-Folder (Join-Path $mc $sub) }
    Ok ("Minecraft cleanup freed {0}" -f (Format-Bytes $total))
}
