# Category: Power  -  dedicated performance power plan + CPU/PCIe/USB power behaviour.
# All power edits go to a separate "PCMC Ultimate Performance" plan; your original plan is never modified.
$script:PlanName = 'PCMC Ultimate Performance'

function Get-ActivePlanGuid { [regex]::Match((& powercfg /getactivescheme | Out-String), $script:GuidRx).Value }

function Get-PcmcPlanGuid {
    foreach ($line in (& powercfg /list)) {
        if ($line -match [regex]::Escape($script:PlanName)) { return [regex]::Match($line, $script:GuidRx).Value }
    }
    return $null
}

function Initialize-PcmcPlan {
    $g = Get-PcmcPlanGuid
    if ($g) { return $g }
    $orig = Get-ActivePlanGuid
    $out = & powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>$null | Out-String
    $g = [regex]::Match($out, $script:GuidRx).Value
    if (-not $g) {
        # Ultimate Performance is missing on some editions -> clone High Performance instead
        $out = & powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2>$null | Out-String
        $g = [regex]::Match($out, $script:GuidRx).Value
    }
    if (-not $g) { throw 'Could not create a performance power plan.' }
    & powercfg /changename $g $script:PlanName | Out-Null
    Add-Journal @{ Type = 'PowerPlan'; Original = $orig; Created = $g }
    return $g
}

function Set-PlanAc([string]$Sub, [string]$Setting, [int]$Value) {
    $g = Initialize-PcmcPlan
    & powercfg /setacvalueindex $g $Sub $Setting $Value | Out-Null
    & powercfg /setactive $g | Out-Null
}

Register-Action -Category 'Power' -Id 'Power.Ultimate' -Tier 1 -Title 'Ultimate Performance power plan' -Description 'Creates and activates a dedicated max-performance plan (original plan is kept for undo).' -Run {
    $g = Initialize-PcmcPlan
    & powercfg /setactive $g | Out-Null
    Ok 'Performance power plan active.'
    if ((Get-SystemSummary).IsLaptop) { Warn 'Laptop detected: this plan raises battery drain. Switch plans when unplugged.' }
}

Register-Action -Category 'Power' -Id 'Power.UsbSuspend' -Tier 2 -Title 'Disable USB selective suspend' -Description 'Stops Windows powering down USB ports (fixes mouse/keyboard/headset hiccups).' -Run {
    Set-PlanAc '2a737441-1930-4402-8d77-b2bebba308a3' '48e6b7a6-50f5-4782-a5d4-53bb8f07e226' 0
    Ok 'USB selective suspend disabled (plugged in).'
}

Register-Action -Category 'Power' -Id 'Power.CpuUnpark' -Tier 3 -Ask -Title 'CPU always-ready (no parking, 100% min state)' -Description 'Keeps all cores unparked and at full minimum state, plus PCIe link power management off.' -Note 'Raises idle power draw and heat. Best on desktops with good cooling.' -Run {
    Set-PlanAc '54533251-82be-4824-96c1-47b60b740d00' '0cc5b647-c1df-4637-891a-dec35c318583' 100   # core parking min cores
    Set-PlanAc '54533251-82be-4824-96c1-47b60b740d00' '893dee8e-2bef-41e0-89c6-b55d0929964c' 100   # processor min state
    Set-PlanAc 'ee12f906-d277-404b-b6da-e5fa1a576df5' '501a4d13-42af-4429-9fd1-a8218c268e20' 0     # PCIe ASPM off
    Ok 'CPU parking off, min processor state 100%, PCIe power saving off.'
}

Register-Action -Category 'Power' -Id 'Power.Hibernate' -Tier 3 -Ask -Title 'Disable hibernation + Fast Startup' -Description 'Frees several GB (hiberfil.sys) and gives clean full shutdowns.' -Note 'You will lose hibernate and Fast Startup (reversible).' -Run {
    & powercfg /h off
    Add-Journal @{ Type = 'Command'; Exe = 'powercfg'; ExeArgs = @('/h', 'on') }
    Ok 'Hibernation disabled.'
}
