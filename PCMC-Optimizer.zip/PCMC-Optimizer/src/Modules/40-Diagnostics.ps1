# Category: Diagnostics  -  read-only tools and the before/after report. Nothing here changes your system.

function Get-Snapshot([string]$Label) {
    $os = Get-CimInstance Win32_OperatingSystem
    $startup = 0
    foreach ($k in 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run') {
        if (Test-Path -LiteralPath $k) { $startup += @((Get-ItemProperty -LiteralPath $k).PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' }).Count }
    }
    $plan = [regex]::Match((& powercfg /getactivescheme | Out-String), '\((.+)\)').Groups[1].Value
    [pscustomobject]@{
        Label           = $Label
        Time            = (Get-Date).ToString('s')
        FreeRAM_GB      = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
        TotalRAM_GB     = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
        Processes       = @(Get-Process).Count
        RunningServices = @(Get-Service | Where-Object { $_.Status -eq 'Running' }).Count
        StartupEntries  = $startup
        FreeDisk_GB     = [math]::Round((Get-PSDrive -Name ($env:SystemDrive.Substring(0, 1))).Free / 1GB, 2)
        PowerPlan       = $plan
    }
}

function Save-Snapshot([string]$Label) {
    $snap = Get-Snapshot $Label
    $file = Join-Path $script:ReportDir ('snapshot-{0}-{1:yyyyMMdd-HHmmss}.json' -f $Label, (Get-Date))
    $snap | ConvertTo-Json | Set-Content -LiteralPath $file -Encoding UTF8
    return $snap
}

Register-Action -Category 'Diagnostics' -Id 'Diagnostics.SystemInfo' -Tier 1 -Manual -Title 'System information' -Description 'CPU, GPU, RAM, drive type, OS build.' -Run {
    (Get-SystemSummary | Format-List | Out-String).TrimEnd() | Write-Host
    Info ("Free space on {0}: {1}" -f $env:SystemDrive, (Format-Bytes (Get-PSDrive -Name ($env:SystemDrive.Substring(0, 1))).Free))
}

Register-Action -Category 'Diagnostics' -Id 'Diagnostics.TopProcesses' -Tier 1 -Manual -Title 'Top CPU and RAM consumers' -Description 'Shows the 10 heaviest processes by memory and by CPU time.' -Run {
    Write-Host '  Top 10 by RAM:' -ForegroundColor White
    Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 |
        ForEach-Object { Write-Host ('   {0,-28} {1,10}' -f $_.ProcessName, (Format-Bytes $_.WorkingSet64)) }
    Write-Host '  Top 10 by CPU time:' -ForegroundColor White
    Get-Process | Where-Object { $_.CPU } | Sort-Object CPU -Descending | Select-Object -First 10 |
        ForEach-Object { Write-Host ('   {0,-28} {1,10:N1} s' -f $_.ProcessName, $_.CPU) }
}

Register-Action -Category 'Diagnostics' -Id 'Diagnostics.Disks' -Tier 1 -Manual -Title 'Drive health and free space' -Description 'Physical disk health status, type and volume usage.' -Run {
    Get-PhysicalDisk | ForEach-Object {
        Write-Host ('   {0,-32} {1,-5} {2,-10} {3}' -f $_.FriendlyName, $_.MediaType, $_.HealthStatus, (Format-Bytes $_.Size))
    }
    Write-Host ''
    Get-Volume | Where-Object { $_.DriveLetter } | ForEach-Object {
        Write-Host ('   {0}:  {1} free of {2}' -f $_.DriveLetter, (Format-Bytes $_.SizeRemaining), (Format-Bytes $_.Size))
    }
}

Register-Action -Category 'Diagnostics' -Id 'Diagnostics.Latency' -Tier 1 -Manual -Title 'Network latency test' -Description 'Pings Cloudflare, Google and Hypixel (4 packets each) and reports average / jitter.' -Run {
    foreach ($target in '1.1.1.1', '8.8.8.8', 'mc.hypixel.net') {
        $ping = New-Object System.Net.NetworkInformation.Ping
        $times = @()
        for ($i = 0; $i -lt 4; $i++) {
            try { $r = $ping.Send($target, 2000); if ($r.Status -eq 'Success') { $times += $r.RoundtripTime } } catch { }
        }
        if ($times.Count -gt 0) {
            $avg = ($times | Measure-Object -Average).Average
            $jit = ($times | Measure-Object -Maximum).Maximum - ($times | Measure-Object -Minimum).Minimum
            Write-Host ('   {0,-18} avg {1,5:N0} ms   jitter {2,3} ms   ({3}/4 replies)' -f $target, $avg, $jit, $times.Count)
        } else { Write-Host ('   {0,-18} no reply' -f $target) -ForegroundColor Yellow }
    }
}

Register-Action -Category 'Diagnostics' -Id 'Diagnostics.Report' -Tier 1 -Manual -Title 'Before/after HTML report' -Description 'Compares the latest "before" snapshot (taken by presets) with now and opens an HTML report.' -Run {
    $now = Save-Snapshot 'after'
    $beforeFile = Get-ChildItem -LiteralPath $script:ReportDir -Filter 'snapshot-before-*.json' -ErrorAction SilentlyContinue |
                  Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $rows = @()
    $before = $null
    if ($beforeFile) { $before = Get-Content -LiteralPath $beforeFile.FullName -Raw | ConvertFrom-Json }
    foreach ($p in $now.PSObject.Properties | Where-Object { $_.Name -notin 'Label', 'Time' }) {
        $rows += [pscustomobject]@{
            Metric = $p.Name
            Before = if ($before) { $before.($p.Name) } else { 'n/a (run a preset first)' }
            Now    = $p.Value
        }
    }
    $sys = Get-SystemSummary
    $html = $rows | ConvertTo-Html -Title 'PCMC Optimizer Report' -PreContent ("<h1>PCMC Optimizer Report</h1><p>{0} | {1} | {2} GB RAM | {3}</p>" -f $sys.CPU, $sys.GPU, $sys.RamGB, (Get-Date)) -PostContent '<p>Generated by PCMC Optimizer.</p>'
    $style = '<style>body{font-family:Segoe UI,sans-serif;background:#10141c;color:#e6edf3;padding:32px}table{border-collapse:collapse;min-width:480px}th,td{padding:8px 16px;border-bottom:1px solid #2a3140;text-align:left}th{color:#58a6ff}h1{color:#58a6ff}</style>'
    $out = Join-Path $script:ReportDir ('report-{0:yyyyMMdd-HHmmss}.html' -f (Get-Date))
    Set-Content -LiteralPath $out -Value (($html -join "`n") -replace '</head>', "$style</head>") -Encoding UTF8
    Ok "Report saved: $out"
    Start-Process $out
}
