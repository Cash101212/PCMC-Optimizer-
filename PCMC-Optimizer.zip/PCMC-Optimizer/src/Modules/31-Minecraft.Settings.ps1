# Category: Minecraft  -  game settings and JVM flags.

Register-Action -Category 'Minecraft' -Id 'Minecraft.Options' -Tier 1 -Title 'Tune video settings (options.txt)' -Description 'Uncapped FPS, no VSync, RAM-aware render distance, minimal particles, fast graphics. All launchers/instances.' -Run {
    if (Test-McRunning) { throw 'Close Minecraft first - it rewrites options.txt when it exits.' }
    $files = @(Get-McOptionFiles)
    if ($files.Count -eq 0) { Warn 'No options.txt found. Launch Minecraft Java once, close it, then retry.'; return }

    $ram    = (Get-SystemSummary).RamGB
    $render = if ($script:Config.RenderDistance)     { [int]$script:Config.RenderDistance }     elseif ($ram -ge 16) { 12 } else { 8 }
    $sim    = if ($script:Config.SimulationDistance) { [int]$script:Config.SimulationDistance } elseif ($ram -ge 16) { 8 }  else { 6 }

    # Only keys that already exist in the file are changed, so versions with different option sets stay valid.
    $tweaks = [ordered]@{
        maxFps = '260'; enableVsync = 'false'; renderDistance = "$render"; simulationDistance = "$sim"
        entityDistanceScaling = '0.75'; particles = '2'; entityShadows = 'false'; ao = 'false'
        biomeBlendRadius = '1'; mipmapLevels = '2'; fancyGraphics = 'false'; graphicsMode = '0'; renderClouds = '"fast"'
    }
    foreach ($f in $files) {
        Backup-File $f | Out-Null
        $lines = [System.IO.File]::ReadAllLines($f)
        $changed = 0
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $k = $lines[$i].Split(':')[0]
            if ($tweaks.Contains($k)) {
                $new = "${k}:$($tweaks[$k])"
                if ($lines[$i] -ne $new) { $lines[$i] = $new; $changed++ }
            }
        }
        [System.IO.File]::WriteAllLines($f, $lines, (New-Object System.Text.UTF8Encoding $false))
        Ok ("{0} setting(s) tuned: {1}" -f $changed, $f)
    }
    Info "Render distance $render, simulation distance $sim. Override in config\settings.json."
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.Jvm' -Tier 1 -Title 'Optimised JVM flags (G1GC, RAM-aware)' -Description 'Applies tuned Java flags to official launcher profiles and saves jvm-args.txt for other launchers.' -Run {
    $jvm = Get-JvmFlags
    $txt = Join-Path $script:DataDir 'jvm-args.txt'
    Set-Content -LiteralPath $txt -Value $jvm -Encoding ASCII
    Ok "JVM flags saved to $txt (paste into Prism / MultiMC / CurseForge / Modrinth App)."

    $lp = Join-Path (Get-McDir) 'launcher_profiles.json'
    if (-not (Test-Path -LiteralPath $lp)) { Info 'Official launcher profiles not found - skipped auto-apply.'; return }
    if (Test-McRunning) { throw 'Close Minecraft / the launcher before editing launcher profiles.' }
    Backup-File $lp | Out-Null
    $json = Get-Content -LiteralPath $lp -Raw | ConvertFrom-Json
    $count = 0
    foreach ($p in $json.profiles.PSObject.Properties) {
        $p.Value | Add-Member -NotePropertyName 'javaArgs' -NotePropertyValue $jvm -Force
        $count++
    }
    Write-TextNoBom $lp ($json | ConvertTo-Json -Depth 20)
    Ok "JVM flags applied to $count launcher profile(s)."
}

Register-Action -Category 'Minecraft' -Id 'Minecraft.Bedrock' -Tier 2 -Title 'Tune Bedrock Edition video settings' -Description 'Caps view distance, disables VSync and fancy graphics in Bedrock options.txt (existing keys only).' -Run {
    if (Test-McRunning) { throw 'Close Minecraft first.' }
    $root = Join-Path $env:APPDATA 'Minecraft Bedrock\Users'
    $files = @()
    if (Test-Path -LiteralPath $root) {
        $files = @(Get-ChildItem -LiteralPath $root -Filter 'options.txt' -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.FullName -like '*minecraftpe*' })
    }
    if ($files.Count -eq 0) { Info 'No Bedrock options.txt found (Bedrock not installed or never launched).'; return }
    foreach ($f in $files) {
        Backup-File $f.FullName | Out-Null
        $lines = [System.IO.File]::ReadAllLines($f.FullName)
        $changed = 0
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match '^gfx_viewdistance:(\d+)$' -and [int]$Matches[1] -gt 16) { $lines[$i] = 'gfx_viewdistance:12'; $changed++ }
            elseif ($lines[$i] -match '^gfx_vsync:1$')         { $lines[$i] = 'gfx_vsync:0'; $changed++ }
            elseif ($lines[$i] -match '^gfx_fancygraphics:1$') { $lines[$i] = 'gfx_fancygraphics:0'; $changed++ }
        }
        [System.IO.File]::WriteAllLines($f.FullName, $lines, (New-Object System.Text.UTF8Encoding $false))
        Ok "$changed Bedrock setting(s) tuned."
    }
}
