# Category: Startup  -  boot time and background tasks.

Register-Action -Category 'Startup' -Id 'Startup.NoDelay' -Tier 1 -Title 'Remove startup app delay' -Description 'Startup apps launch immediately after sign-in instead of waiting ~10 seconds.' -Run {
    Set-Reg 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' 'StartupDelayInMSec' 0 | Out-Null
    Ok 'Startup delay removed.'
}

Register-Action -Category 'Startup' -Id 'Startup.Tasks' -Tier 2 -Title 'Disable telemetry scheduled tasks' -Description 'Compatibility Appraiser, CEIP and Application Experience tasks (re-enabled by Undo).' -Run {
    $tasks = @(
        @{ P = '\Microsoft\Windows\Application Experience\';             N = 'Microsoft Compatibility Appraiser' },
        @{ P = '\Microsoft\Windows\Application Experience\';             N = 'ProgramDataUpdater' },
        @{ P = '\Microsoft\Windows\Customer Experience Improvement Program\'; N = 'Consolidator' },
        @{ P = '\Microsoft\Windows\Customer Experience Improvement Program\'; N = 'UsbCeip' },
        @{ P = '\Microsoft\Windows\Autochk\';                             N = 'Proxy' }
    )
    foreach ($t in $tasks) {
        $task = Get-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction SilentlyContinue
        if ($task -and $task.State -ne 'Disabled') {
            Disable-ScheduledTask -TaskPath $t.P -TaskName $t.N -ErrorAction SilentlyContinue | Out-Null
            Add-Journal @{ Type = 'Task'; TaskPath = $t.P; TaskName = $t.N }
            Ok "Task disabled: $($t.N)"
        }
    }
}

Register-Action -Category 'Startup' -Id 'Startup.Manager' -Tier 3 -Manual -Title 'Startup manager (choose apps to disable)' -Description 'Lists Run-key startup entries; disable the ones you do not need. Fully reversible.' -Run {
    $locs = @(
        @{ Scope = 'User';    Run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
           Approved = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' },
        @{ Scope = 'Machine'; Run = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
           Approved = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
    )
    $items = @()
    foreach ($l in $locs) {
        if (-not (Test-Path -LiteralPath $l.Run)) { continue }
        foreach ($p in @((Get-ItemProperty -LiteralPath $l.Run).PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' })) {
            $items += [pscustomobject]@{ Name = $p.Name; Cmd = [string]$p.Value; Approved = $l.Approved; Scope = $l.Scope }
        }
    }
    if ($items.Count -eq 0) { Info 'No startup entries found.'; return }
    $i = 1
    foreach ($it in $items) {
        Write-Host ('  {0,2}) {1,-32} [{2}]' -f $i, $it.Name, $it.Scope)
        Write-Host ('      ' + $it.Cmd.Substring(0, [math]::Min(88, $it.Cmd.Length))) -ForegroundColor DarkGray
        $i++
    }
    $sel = Read-Host "`n  Numbers to disable (e.g. 1,3) or Enter to skip"
    if ([string]::IsNullOrWhiteSpace($sel)) { return }
    $disabled = [byte[]](3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    foreach ($n in ($sel -split '[,\s]+' | Where-Object { $_ -match '^\d+$' })) {
        $idx = [int]$n - 1
        if ($idx -ge 0 -and $idx -lt $items.Count) {
            $it = $items[$idx]
            if (Set-Reg $it.Approved $it.Name $disabled 'Binary') { Ok "Disabled at startup: $($it.Name)" }
        }
    }
}
