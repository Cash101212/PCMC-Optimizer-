# Category: Storage  -  safe cleanup and drive maintenance. Only caches/temp data is touched.

function Write-Freed([string]$What, [double]$Bytes) { Ok ("{0}: freed {1}" -f $What, (Format-Bytes $Bytes)) }

Register-Action -Category 'Storage' -Id 'Storage.TempFiles' -Tier 1 -Title 'Clean temp files' -Description 'User temp, Windows temp, crash dumps, CBS logs and thumbnail/INet caches.' -Run {
    $total = 0
    $targets = @($env:TEMP, "$env:SystemRoot\Temp", "$env:LOCALAPPDATA\CrashDumps", "$env:SystemRoot\Logs\CBS",
                 "$env:LOCALAPPDATA\Microsoft\Windows\INetCache", "$env:LOCALAPPDATA\Microsoft\Windows\Explorer")
    foreach ($t in $targets) {
        if ($t -like '*\Explorer') {
            # only thumbnail/icon caches, not the whole Explorer folder
            foreach ($f in @(Get-ChildItem -LiteralPath $t -Filter 'thumbcache_*.db' -Force -ErrorAction SilentlyContinue)) {
                $total += $f.Length; Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue
            }
        } else { $total += Clear-Folder $t }
    }
    Write-Freed 'Temp files' $total
}

Register-Action -Category 'Storage' -Id 'Storage.ShaderCaches' -Tier 1 -Title 'Clear GPU shader caches' -Description 'DirectX, NVIDIA and AMD shader caches (rebuilt automatically; fixes stutter after driver updates).' -Run {
    $total = 0
    $targets = @("$env:LOCALAPPDATA\D3DSCache", "$env:LOCALAPPDATA\NVIDIA\DXCache", "$env:LOCALAPPDATA\NVIDIA\GLCache",
                 "$env:LOCALAPPDATA\AMD\DxCache", "$env:LOCALAPPDATA\AMD\GLCache", "$env:LOCALAPPDATA\AMD\VkCache")
    foreach ($t in $targets) { $total += Clear-Folder $t }
    Write-Freed 'Shader caches' $total
    Info 'First launch of each game may stutter briefly while shaders rebuild.'
}

Register-Action -Category 'Storage' -Id 'Storage.WindowsUpdateCache' -Tier 1 -Title 'Clear Windows Update download cache' -Description 'Removes already-downloaded update files (SoftwareDistribution\Download).' -Run {
    $freed = 0
    try {
        Stop-Service -Name wuauserv -Force -ErrorAction Stop
        $freed = Clear-Folder "$env:SystemRoot\SoftwareDistribution\Download"
    } finally {
        Start-Service -Name wuauserv -ErrorAction SilentlyContinue
    }
    Write-Freed 'Windows Update cache' $freed
}

Register-Action -Category 'Storage' -Id 'Storage.RecycleBin' -Tier 1 -Title 'Empty Recycle Bin' -Description 'Permanently deletes everything in the Recycle Bin.' -Run {
    try { Clear-RecycleBin -Force -ErrorAction Stop; Ok 'Recycle Bin emptied.' } catch { Info 'Recycle Bin already empty.' }
}

Register-Action -Category 'Storage' -Id 'Storage.Trim' -Tier 1 -Title 'TRIM SSD / optimise drive' -Description 'Runs ReTrim on SSDs; skips defrag on HDDs.' -Run {
    if ((Get-SystemSummary).IsSsd) {
        Optimize-Volume -DriveLetter ($env:SystemDrive.Substring(0, 1)) -ReTrim -ErrorAction Stop | Out-Null
        Ok 'SSD TRIM completed.'
    } else { Info 'System drive is not an SSD - skipped (use scheduled defrag for HDDs).' }
}

Register-Action -Category 'Storage' -Id 'Storage.BrowserCache' -Tier 2 -Title 'Clear browser caches (Chrome, Edge, Firefox)' -Description 'Cache only - bookmarks, passwords and logins are untouched. Close browsers first.' -Run {
    $total = 0
    $globs = @("$env:LOCALAPPDATA\Google\Chrome\User Data\*\Cache\Cache_Data", "$env:LOCALAPPDATA\Google\Chrome\User Data\*\Code Cache",
               "$env:LOCALAPPDATA\Microsoft\Edge\User Data\*\Cache\Cache_Data", "$env:LOCALAPPDATA\Microsoft\Edge\User Data\*\Code Cache",
               "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles\*\cache2")
    foreach ($g in $globs) {
        foreach ($d in @(Get-ChildItem -Path $g -Directory -ErrorAction SilentlyContinue)) { $total += Clear-Folder $d.FullName }
    }
    Write-Freed 'Browser caches' $total
}

Register-Action -Category 'Storage' -Id 'Storage.StorageSense' -Tier 2 -Title 'Enable Storage Sense' -Description 'Lets Windows auto-clean temp files and the Recycle Bin on a schedule.' -Run {
    $p = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'
    Set-Reg $p '01' 1 | Out-Null
    Set-Reg $p '04' 1 | Out-Null
    Ok 'Storage Sense enabled.'
}

Register-Action -Category 'Storage' -Id 'Storage.ComponentStore' -Tier 3 -Ask -Manual -Title 'DISM component store cleanup (slow)' -Description 'Removes superseded Windows components. Takes 2-10 minutes, can free several GB.' -Note 'Slow but safe. Updates can no longer be uninstalled after this.' -Run {
    Info 'Running DISM - please wait...'
    & Dism.exe /Online /Cleanup-Image /StartComponentCleanup | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "DISM exited with code $LASTEXITCODE" }
    Ok 'Component store cleaned.'
}
