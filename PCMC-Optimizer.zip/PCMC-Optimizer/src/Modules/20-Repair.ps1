# Category: Repair  -  built-in Windows repair tools. All manual (never part of a preset).

Register-Action -Category 'Repair' -Id 'Repair.Sfc' -Tier 1 -Manual -Title 'System File Checker (sfc /scannow)' -Description 'Scans and repairs corrupted Windows system files (5-15 minutes).' -Run {
    Info 'Running SFC - this takes a while...'
    & sfc.exe /scannow
    Ok 'SFC finished. Review the result above.'
}

Register-Action -Category 'Repair' -Id 'Repair.DismHealth' -Tier 1 -Manual -Title 'DISM RestoreHealth' -Description 'Repairs the Windows component store (needs internet; 5-20 minutes).' -Run {
    Info 'Running DISM RestoreHealth...'
    & Dism.exe /Online /Cleanup-Image /RestoreHealth
    if ($LASTEXITCODE -ne 0) { throw "DISM exited with code $LASTEXITCODE" }
    Ok 'DISM RestoreHealth completed.'
}

Register-Action -Category 'Repair' -Id 'Repair.NetworkReset' -Tier 2 -Ask -Manual -Reboot -Title 'Reset network stack (Winsock + IP)' -Description 'Fixes broken connectivity. You may need to re-enter static IP settings.' -Note 'Resets Winsock and TCP/IP to defaults. Restart required.' -Run {
    & netsh winsock reset | Out-Null
    & netsh int ip reset | Out-Null
    Clear-DnsClientCache
    Ok 'Network stack reset. Restart your PC.'
}
