# Pester 5 tests: verify the action registry is consistent (does not change the system).
BeforeAll {
    $script:DryRun = $true
    . (Join-Path (Split-Path $PSScriptRoot -Parent) 'src\Load.ps1')
}

Describe 'Action registry' {
    It 'registers actions' {
        $script:Actions.Count | Should -BeGreaterThan 40
    }
    It 'has unique ids' {
        @($script:Actions.Id | Select-Object -Unique).Count | Should -Be $script:Actions.Count
    }
    It 'uses Category.Name ids that match their category' {
        foreach ($a in $script:Actions) { $a.Id | Should -BeLike "$($a.Category).*" }
    }
    It 'has a tier between 1 and 3 and a script block' {
        foreach ($a in $script:Actions) {
            $a.Tier | Should -BeIn 1, 2, 3
            $a.Run  | Should -BeOfType [scriptblock]
        }
    }
    It 'has a title and description for every action' {
        foreach ($a in $script:Actions) {
            $a.Title | Should -Not -BeNullOrEmpty
            $a.Description | Should -Not -BeNullOrEmpty
        }
    }
}

Describe 'Files' {
    It 'keeps all scripts ASCII-only (Windows PowerShell 5.1 safe)' {
        $bad = Get-ChildItem (Split-Path $PSScriptRoot -Parent) -Recurse -Filter *.ps1 | Where-Object {
            [System.IO.File]::ReadAllBytes($_.FullName) | Where-Object { $_ -gt 127 } | Select-Object -First 1
        }
        @($bad).Count | Should -Be 0
    }
}
