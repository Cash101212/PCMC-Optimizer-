# Contributing

## Adding a tweak
1. Pick the module in `src/Modules` that matches the category (or add a new `NN-Name.ps1` file).
2. Register an action:

```powershell
Register-Action -Category 'Gaming' -Id 'Gaming.Example' -Tier 2 -Title 'Short title' -Description 'One sentence.' -Run {
    Set-Reg 'HKCU:\Software\Example' 'Value' 1 | Out-Null   # journaled -> Undo works
    Ok 'Done.'
}
```

3. Rules
   - Always change the registry with `Set-Reg`, back files up with `Backup-File`, and call `Add-Journal` for anything else you can reverse.
   - Be honest with the tier. Anything hardware-dependent or with trade-offs is Tier 3 and should use `-Ask` with a `-Note`.
   - Interactive, slow or diagnostic actions use `-Manual` so presets skip them.
   - Keep files **ASCII-only** (no smart quotes or box characters) so Windows PowerShell 5.1 parses them.
   - No "magic" tweaks without a reason: if a tweak does not measurably help, do not add it.
4. Run `tools/New-ModuleDocs.ps1` and commit the updated `docs/MODULES.md`.
5. Test with `.\PCMC-Optimizer.ps1 -Run Your.Id -DryRun`, then for real, then `-Undo`.
