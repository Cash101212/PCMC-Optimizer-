# Minecraft guide

## What the Minecraft category does

| Action | Effect |
|--------|--------|
| `Minecraft.Options` | Edits `options.txt` for the official launcher and every detected Prism / MultiMC / PolyMC / CurseForge / Modrinth App / ATLauncher instance. Only existing keys are changed. |
| `Minecraft.Jvm` | Writes RAM-aware G1GC flags to launcher profiles and to `jvm-args.txt` for other launchers. |
| `Minecraft.Gpu` | Forces the high-performance GPU for each detected `javaw.exe` (laptops / hybrid graphics). |
| `Minecraft.CpuPriority` | Starts `javaw.exe` with High CPU priority. |
| `Minecraft.Defender` | Adds a Defender exclusion for the game folder (small security trade-off, asks first). |
| `Minecraft.Cleanup` | Clears logs, crash reports and web cache. |
| `Minecraft.Bedrock` | Caps view distance and disables VSync / fancy graphics in Bedrock options. |
| `Minecraft.Mods` | Downloads Sodium, Lithium, FerriteCore, ModernFix, Entity Culling, Iris and Fabric API from Modrinth with SHA-512 verification. |
| `Minecraft.BackupWorlds` | Zips your `saves` folder. |
| `Minecraft.JavaInfo` | Lists Java runtimes and which version you need. |

## RAM allocation

| System RAM | Minecraft heap |
|-----------|----------------|
| up to 8 GB | 3 GB |
| up to 16 GB | 4 GB |
| up to 32 GB | 6 GB |
| above 32 GB | 8 GB |

More is not better: very large heaps make garbage-collection pauses longer. Override with `RamAllocationGB` in `config/settings.json`.

## Where the real FPS comes from

1. **Sodium + Lithium + FerriteCore + ModernFix** (Fabric) usually matter more than any Windows tweak.
2. **Right Java version** (21 for 1.21+).
3. **Dedicated GPU actually used** (`Minecraft.Gpu`).
4. **Sensible render/simulation distance**.

## Tips

- Close Minecraft and the launcher before running Minecraft actions; the game rewrites `options.txt` on exit.
- Use `-DryRun` first to preview.
- Custom install location? Set `MinecraftDir` in `config/settings.json`.
