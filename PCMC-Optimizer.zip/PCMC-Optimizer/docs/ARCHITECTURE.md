# Architecture

```
PCMC-Optimizer.ps1     entry point: parameters, elevation, dispatch
Run.bat                double-click launcher
config/settings.json   user configuration
src/
  Load.ps1             dot-sources Core then Modules (also used by tests)
  Core/
    00-Config.ps1      paths, version, settings
    01-Logging.ps1     Ok/Info/Warn/Bad/Head + log file
    02-UI.ps1          banner, prompts, tier colours
    03-Journal.ps1     change journal + Undo-All
    04-System.ps1      Set-Reg, system facts, backups, restore point
    05-Engine.ps1      Register-Action, Invoke-Action, presets
    06-Menu.ps1        menus generated from registered actions
  Modules/
    10-Power ... 20-Repair, 30-33 Minecraft, 40-Diagnostics
docs/                  MODULES (generated), SAFETY, MINECRAFT, ARCHITECTURE
tests/                 Pester tests for the registry
tools/                 New-ModuleDocs.ps1
```

## How it fits together

- A **module** is just a `.ps1` file that calls `Register-Action`. Files load in name order, so categories appear in the menu in that order.
- The **engine** stores actions with a category, id, tier and script block. Menus, presets, `-Run` and `-List` are all generated from that list.
- **Presets** run every non-manual action with `Tier <= level` (Safe = 1, Balanced = 2, Extreme = 3).
- Every change goes through helpers (`Set-Reg`, `Backup-File`, `Add-Journal`) that feed the **journal**, which powers Undo.
- Adding a new category needs no menu code: create `NN-Name.ps1` and register actions.
