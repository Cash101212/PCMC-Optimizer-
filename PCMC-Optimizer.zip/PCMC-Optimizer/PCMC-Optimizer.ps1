<#
.SYNOPSIS
    PCMC Optimizer - modular, reversible performance toolkit for Windows 10/11 and Minecraft.

.DESCRIPTION
    Interactive menu by default. Every tweak is a registered "action" inside src\Modules,
    grouped by category, tiered by risk (1 Safe, 2 Moderate, 3 Advanced) and journaled
    so it can be undone.

.PARAMETER Preset
    Run a preset non-interactively: Safe, Balanced or Extreme.
.PARAMETER Run
    Run specific action ids or categories, e.g. -Run Power.Ultimate,Minecraft
.PARAMETER List
    List every action and exit.
.PARAMETER Undo
    Revert everything recorded in the journal and exit.
.PARAMETER DryRun
    Show what would run without changing anything.
.PARAMETER Yes
    Auto-accept prompts (uses each prompt's default; Ask-flagged steps are accepted).
.PARAMETER NoRestorePoint
    Skip creating a System Restore point.

.EXAMPLE
    .\PCMC-Optimizer.ps1
.EXAMPLE
    .\PCMC-Optimizer.ps1 -Preset Balanced -Yes
.EXAMPLE
    .\PCMC-Optimizer.ps1 -Run Minecraft.Options,Minecraft.Jvm -DryRun
#>
#Requires -Version 5.1
[CmdletBinding()]
param(
    [ValidateSet('Safe', 'Balanced', 'Extreme')][string]$Preset,
    [string[]]$Run,
    [switch]$List,
    [switch]$Undo,
    [switch]$DryRun,
    [switch]$Yes,
    [switch]$NoRestorePoint
)

$script:DryRun         = [bool]$DryRun
$script:Yes            = [bool]$Yes
$script:NoRestorePoint = [bool]$NoRestorePoint
$script:NonInteractive = [bool]($Preset -or $Run -or $List -or $Undo)

. (Join-Path $PSScriptRoot 'src\Load.ps1')

# ---- elevate (forward all parameters) -------------------------------------
if (-not $List -and -not (Test-Admin)) {
    Write-Host 'Requesting administrator rights...' -ForegroundColor Yellow
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    foreach ($k in $PSBoundParameters.Keys) {
        $v = $PSBoundParameters[$k]
        if ($v -is [switch]) { if ($v.IsPresent) { $argList += "-$k" } }
        elseif ($v -is [array]) { $argList += "-$k"; $argList += ($v -join ',') }
        else { $argList += "-$k"; $argList += "$v" }
    }
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argList
    exit
}

Remove-OldLogs
Log "Started v$($script:Version) preset='$Preset' run='$Run' dry=$($script:DryRun)"

if ($Run) { $Run = @($Run | ForEach-Object { $_ -split ',' } | Where-Object { $_ }) }

if     ($List)   { Show-ActionList }
elseif ($Undo)   { Undo-All }
elseif ($Preset) { Invoke-Preset $Preset }
elseif ($Run)    { Invoke-ByIds $Run }
else             { Show-MainMenu }
